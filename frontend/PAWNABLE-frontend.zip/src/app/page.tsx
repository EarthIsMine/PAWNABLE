"use client"

import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Navbar } from "@/components/navbar"
import { ArrowRight, Shield, TrendingUp, Users, Clock } from "lucide-react"
import { useTranslations } from "next-intl"

export default function HomePage() {
  const t = useTranslations("home")

  return (
    <div className="min-h-screen bg-background">
      <Navbar />

      {/* Hero Section */}
      <section className="container mx-auto px-4 py-20 md:py-32">
        <div className="mx-auto max-w-4xl text-center">
          <div className="mb-6 inline-block rounded-full border border-primary/20 bg-primary/10 px-4 py-1.5">
            <span className="text-sm font-medium text-primary">{t("badge")}</span>
          </div>

          <h1 className="mb-6 text-4xl font-bold tracking-tight text-balance sm:text-5xl md:text-6xl lg:text-7xl">
            {t("title")}
          </h1>

          <p className="mb-8 text-lg text-muted-foreground text-pretty md:text-xl">{t("subtitle")}</p>

          <div className="flex flex-col items-center justify-center gap-4 sm:flex-row">
            <Link href="/marketplace">
              <Button size="lg" className="gap-2">
                {t("exploreMarketplace")}
                <ArrowRight className="h-4 w-4" />
              </Button>
            </Link>
            <Link href="/create-loan">
              <Button size="lg" variant="outline">
                {t("createLoanRequest")}
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="border-y border-border bg-card/50">
        <div className="container mx-auto px-4 py-12">
          <div className="grid gap-8 sm:grid-cols-2 lg:grid-cols-4">
            <div className="text-center">
              <div className="mb-2 text-3xl font-bold text-primary">0.5%</div>
              <div className="text-sm text-muted-foreground">{t("stats.platformFee")}</div>
            </div>
            <div className="text-center">
              <div className="mb-2 text-3xl font-bold text-primary">P2P</div>
              <div className="text-sm text-muted-foreground">{t("stats.directMatching")}</div>
            </div>
            <div className="text-center">
              <div className="mb-2 text-3xl font-bold text-primary">{t("stats.flexible")}</div>
              <div className="text-sm text-muted-foreground">{t("stats.yourRates")}</div>
            </div>
            <div className="text-center">
              <div className="mb-2 text-3xl font-bold text-primary">{t("stats.secure")}</div>
              <div className="text-sm text-muted-foreground">{t("stats.smartContracts")}</div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="container mx-auto px-4 py-20">
        <div className="mx-auto max-w-2xl text-center mb-16">
          <h2 className="mb-4 text-3xl font-bold text-balance md:text-4xl">{t("howItWorks.title")}</h2>
          <p className="text-muted-foreground text-pretty">{t("howItWorks.subtitle")}</p>
        </div>

        <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-4">
          <Card>
            <CardContent className="p-6">
              <div className="mb-4 inline-flex h-12 w-12 items-center justify-center rounded-lg bg-primary/10">
                <Users className="h-6 w-6 text-primary" />
              </div>
              <h3 className="mb-2 text-xl font-semibold text-balance">{t("howItWorks.features.setTerms.title")}</h3>
              <p className="text-sm text-muted-foreground text-pretty">
                {t("howItWorks.features.setTerms.description")}
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="mb-4 inline-flex h-12 w-12 items-center justify-center rounded-lg bg-primary/10">
                <Shield className="h-6 w-6 text-primary" />
              </div>
              <h3 className="mb-2 text-xl font-semibold text-balance">{t("howItWorks.features.collateral.title")}</h3>
              <p className="text-sm text-muted-foreground text-pretty">
                {t("howItWorks.features.collateral.description")}
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="mb-4 inline-flex h-12 w-12 items-center justify-center rounded-lg bg-primary/10">
                <TrendingUp className="h-6 w-6 text-primary" />
              </div>
              <h3 className="mb-2 text-xl font-semibold text-balance">{t("howItWorks.features.deadlines.title")}</h3>
              <p className="text-sm text-muted-foreground text-pretty">
                {t("howItWorks.features.deadlines.description")}
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="mb-4 inline-flex h-12 w-12 items-center justify-center rounded-lg bg-primary/10">
                <Clock className="h-6 w-6 text-primary" />
              </div>
              <h3 className="mb-2 text-xl font-semibold text-balance">{t("howItWorks.features.matching.title")}</h3>
              <p className="text-sm text-muted-foreground text-pretty">
                {t("howItWorks.features.matching.description")}
              </p>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* CTA Section */}
      <section className="border-t border-border bg-card/50">
        <div className="container mx-auto px-4 py-20">
          <div className="mx-auto max-w-3xl text-center">
            <h2 className="mb-4 text-3xl font-bold text-balance md:text-4xl">{t("cta.title")}</h2>
            <p className="mb-8 text-muted-foreground text-pretty">{t("cta.subtitle")}</p>
            <Link href="/marketplace">
              <Button size="lg" className="gap-2">
                {t("cta.viewMarketplace")}
                <ArrowRight className="h-4 w-4" />
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-border">
        <div className="container mx-auto px-4 py-8">
          <div className="flex flex-col items-center justify-between gap-4 sm:flex-row">
            <p className="text-sm text-muted-foreground">{t("footer.testnet")}</p>
            <div className="flex gap-6">
              <Link href="#" className="text-sm text-muted-foreground hover:text-foreground">
                {t("footer.docs")}
              </Link>
              <Link href="#" className="text-sm text-muted-foreground hover:text-foreground">
                {t("footer.github")}
              </Link>
              <Link href="#" className="text-sm text-muted-foreground hover:text-foreground">
                {t("footer.discord")}
              </Link>
            </div>
          </div>
        </div>
      </footer>
    </div>
  )
}
